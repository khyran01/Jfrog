# jfrog-pipelines-simple-example

This is a simple "Hello world" level example that gets you up and running with JFrog Pipelines. Detailed instructions on how to run this sample, as well as explanation of the configuration, is in the JFrog Pipelines Quickstart documentation: [Pipelines Example: Hello World](https://www.jfrog.com/confluence/display/JFROG/Pipeline+Example%3A+Hello+World).
